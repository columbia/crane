cat BULK_LOAD.script     | timer.pl > BULK_LOAD.out
cat BULK_LOAD_RAW.script | timer.pl > BULK_LOAD_RAW.out
cat LLADD_HASH_TPS.script| timer.pl > LLADD_HASH_TPS.out
cat TPS.script           | timer.pl > TPS.out
cat SEDA.script          | timer.pl > SEDA.out


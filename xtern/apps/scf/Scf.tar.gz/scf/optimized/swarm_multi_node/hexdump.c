/*
 * hexdump.c
 *
 *  Created on: Mar 2, 2012
 *      Author: infinoid
 */

#include <stdio.h>
#include <stdint.h>
#include <sys/types.h>

#define ROW 16
#define MASK ((ROW-1))
void hexdump(char *prefix, char *buf, size_t len) {
    int begin = 1, pad = 1;
    for(; len; len--, buf++) {
        int yep;
        if(begin) {
            printf("%s %p", prefix, (void*)((uint64_t)buf & ~(ROW-1)));
            begin = 0;
        }
        if(pad) {
            char *tmp;
            for(tmp = (char*)((uint64_t)buf & ~(ROW-1)); tmp < buf; tmp++) {
                printf("   ");
                if((((uint64_t)tmp - ((uint64_t)buf & ~MASK)) & 3) == 3)
                    printf(" ");
            }
            pad = 0;
        }
        yep = *buf & 0xff;
        printf(" %02x", yep);
        if(((uint64_t)buf & MASK) == 15) {
            printf("\n");
            begin++;
        } else
        if(((uint64_t)buf & 3) == 3) {
            printf(" ");
        }
    }
    if((uint64_t)buf & (ROW-1))
        printf("\n");
}

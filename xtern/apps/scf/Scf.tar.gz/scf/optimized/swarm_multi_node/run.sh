#!/bin/sh

if [ $# -lt 2 ]
then
	echo "Usage: $0 START FINISH [swarmrun-args]"
	exit
fi

begin=$1
end=$2
shift 2

for i in `seq $begin $end`
do
	echo $i > be.inpt
	echo >> be.inpt

	for atom in `seq 1 $i`
	do
		printf "4  %.3f 0.000 0.000\n" $(( 4 * ($atom - 1) )) >> be.inpt
	done

	script -fc "swarmrun $* ./scf.x" scf_output.$i
done

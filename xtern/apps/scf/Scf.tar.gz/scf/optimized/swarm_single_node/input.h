
extern void input(void);

extern double exprjh(double x);

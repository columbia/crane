extern void output(double *z, int rowlow, int rowhi, int collow, int colhi, int rowdim, int coldim, int nctl);

#!/bin/sh


if [ $# -eq 0 ]
then
	echo "Usage: $0 START [FINISH]"
	exit
fi

begin=$1

if [ $# -gt 1 ]
then
	end=$2
else
	end=$begin
fi

echo "atoms,onel,twoel,diag,dens,eigen,total,iterations,compute,fraction"

for i in `seq $begin $end`
do
	file=scf_output.$i
	atoms=`grep atoms $file | sed -e 's/.* //' -e 's/[^0-9]//g'`
	iterations=$(( 1 + `grep iter= $file |tail -n1 | sed -e 's/ iter=  //' |cut -f1 -d,` ))
	mem=`grep -A1 cache $file| tail -n1 | sed -e 's/[^0-9]//g'`
	mb=$(( mem / (1024 * 1024) ))
	
	total=`grep elapsed $file | sed -e 's/.* //' -e 's/[^.0-9]//g'`
	times=`grep -A2 diag $file |tail -n1 | sed -r -e 's/ +/ /g' -e 's/^ //'`
	
	onel=`echo $times | cut -f 2 -d" "`
	twoel=`echo $times | cut -f 3 -d" "`
	diag=`echo $times | cut -f 4 -d" "`
	dens=`echo $times | cut -f 5 -d" "`
	eigen=`echo $times | cut -f 7 -d" " | sed -e 's/[^.0-9]//g'`
	
	integrals=`grep -A2 fraction $file |tail -n1 | sed -r -e 's/ +/ /g' -e 's/^ //'`
	compute=`echo $integrals | cut -f4 -d" "`
	fraction=`echo $integrals | cut -f6 -d" "`
	
	echo $atoms,$onel,$twoel,$diag,$dens,$eigen,$total,$iterations,$(( compute / $iterations)),$fraction
done

#!/bin/sh

if [ $# -eq 0 ]
then
	echo "Usage: $0 START [FINISH]"
	exit
fi

begin=$1

if [ $# -gt 1 ]
then
	end=$2
else
	end=$begin
fi

for i in `seq $begin $end`
do
	echo $i > be.inpt
	echo >> be.inpt
	
	for atom in `seq 1 $i`
	do
		printf "4  %.3f 0.000 0.000\n" $(( 4 * ($atom - 1) )) >> be.inpt
	done
	
	script -c ./scf.x scf_output.$i
done


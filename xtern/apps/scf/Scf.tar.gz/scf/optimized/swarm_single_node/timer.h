
extern double timer(void);
extern double timer2(void);

/*
 * twoel.c
 *
 *  Created on: Jan 16, 2013
 *      Author: adam
 */

#include <stdio.h>
#include <string.h>
#include <swarm/Runtime.h>
#include <swarm/Codelet.h>
#include <swarm/util/atomic.h>
#include <eti/swarm_convenience.h>
#include <eti/tracing.h>

#include "cscc.h"
#include "g.h"

double contract_matrices(double *, double *);
extern double schwmax;
extern swarm_Runtime_t* runtime;

const swarm_Codelet_t* finalize_codelet;
void* finalize_context;

/* Declare codelets: */
CODELET_DECL(twoel_symm);
CODELET_DECL(twoel_local_reduction);

swarm_Dep_t dep;


#define OFF(a, b)             ((a ##_off) + (b))
#define DENS(a, b)            (g_dens_ ## a ## _ ## b)

#define DENS_DECL(a, b)       double g_dens_ ## a ## _ ## b = g_dens[OFF(a,b)]

#ifdef BAD_CACHE_UTILIZATION
#define DENS_DECL_SYMM(a, b)  double g_dens_ ## a ## _ ## b = g_dens[OFF(a,b)]; \
                              double g_dens_ ## b ## _ ## a = g_dens[OFF(b,a)]
#else
#define DENS_DECL_SYMM(a, b)  double g_dens_ ## a ## _ ## b = g_dens[OFF(a,b)]; \
                              double g_dens_ ## b ## _ ## a = g_dens_ ## a ## _ ## b
#endif

#define TOL_DECL(a, b)        double tol2e_over_g_schwarz_ ## a ## _ ## b = tol2e / g_schwarz[OFF(a,b)]


#define UPDATE(a, b, c, d) fock[OFF(a,b)] += (gg * DENS(c,d)); \
                           fock[OFF(a,c)] -= (0.50 * gg * DENS(b,d));

#define UPDATE_COULOMB1(a, b, c, d)  fock[OFF(a,b)] += (gg * DENS(c,d))
#define UPDATE_COULOMB2(a, b, c, d)  fock[OFF(a,b)] += (gg * DENS(c,d)) + (gg * DENS(c,d))
#define UPDATE_EXCHANGE(a, b, c, d)  fock[OFF(a,c)] -= (0.50 * gg * DENS(b,d));

#ifndef NO_BOOKKEEPING
#define CUT_DECLS       long long int temp_icut1 = 0; \
                        long long int temp_icut2 = 0; \
                        long long int temp_icut3 = 0; \
                        long long int temp_icut4 = 0
#define CUT_WRITEBACK   twoel_context[thread].icut1 += temp_icut1; \
                        twoel_context[thread].icut2 += temp_icut2; \
                        twoel_context[thread].icut3 += temp_icut3; \
                        twoel_context[thread].icut4 += temp_icut4

#define CUT1(N)   temp_icut1 += N
#define CUT2(N)   temp_icut2 += N
#define CUT3(N)   temp_icut3 += N
#define CUT4(N)   temp_icut4 += N
#else
#define CUT1(N)
#define CUT2(N)
#define CUT3(N)
#define CUT4(N)
#define CUT_DECLS
#define CUT_WRITEBACK
#endif

#ifndef NO_PRECALC
#define G(a, b, c, d) g_fast(OFF(a, b), OFF(c, d))
#else
#define G(a, b, c, d) g(a, b, c, d)
#endif

volatile int g_i;
volatile int g_ij;
volatile int g_kl;
volatile int g_codelet_num;

#define CHUNK_SIZE 1
#define N3_CHUNK_SIZE 4

#define SYMM_N3

inline int get_work_unit() {
  return swarm_atomic_getAndAdd(g_i, CHUNK_SIZE);
}

inline int get_work_unit_ij() {
  return swarm_atomic_getAndAdd(g_ij, N3_CHUNK_SIZE);
}

inline int get_work_unit_kl() {
  return swarm_atomic_getAndAdd(g_kl, N3_CHUNK_SIZE);
}



void twoel_i_j_k_l_all_different(double tol2e_over_schwmax, size_t thread) {
  CUT_DECLS;
  int i, j, k, l;
  int i_off, j_off, k_off, l_off;
  double* fock = twoel_context[thread].fock;

  // 8-way symmetry
  while ((i = get_work_unit()) < nbfn) {
    int end = i + CHUNK_SIZE;
    i_off = (i-1) * nbfn;

    for (; i < nbfn && i < end; i++) {
      i_off += nbfn;
      j_off = i_off;

      for (j = i + 1; j < nbfn; j++) {
        j_off += nbfn;
        DENS_DECL_SYMM(j,i);
        TOL_DECL(i,j);

        if (g_schwarz[OFF(i,j)] < tol2e_over_schwmax) {
          CUT1(8 * (-2*j + i*(3-2*nbfn) + i*i + nbfn*(nbfn - 1))/2);
          continue;
        }
        k_off = i_off - nbfn;

        for (k = i; k < nbfn; k++) {
          k_off += nbfn;
          DENS_DECL_SYMM(k,i);
          DENS_DECL_SYMM(k,j);
          if (g_schwarz_max_j[k] < tol2e_over_g_schwarz_i_j) {
            CUT4(8 * ((k==i) ? nbfn - j - 1: nbfn - k - 1));
            continue;
          }

          l_off = ((k == i) ? j_off : k_off);
          for (l = 1 + ((k == i) ? j : k); l < nbfn; l++) {
            l_off += nbfn;

            if (g_schwarz[OFF(k,l)] < tol2e_over_g_schwarz_i_j) {
              CUT2(8);
              continue;
            }

            DENS_DECL_SYMM(l,i);
            DENS_DECL_SYMM(l,j);
            DENS_DECL_SYMM(l,k);

            CUT3(8);
            double gg = G(i, j, k, l);

#ifdef BAD_CACHE_UTILIZATION
            UPDATE(i,j,k,l);
            UPDATE(i,j,l,k);
            UPDATE(j,i,k,l);
            UPDATE(j,i,l,k);
            UPDATE(k,l,i,j);
            UPDATE(k,l,j,i);
            UPDATE(l,k,i,j);
            UPDATE(l,k,j,i);
#else
            /*
             * Exploiting yet another symmetry to make the faster and harder to read:
             * - g_dens is a symmetric matrix
             * - g_fock is a symmetric matrix
             *
             * The normal update sequence pulls identical values from both triangles
             * of g_dens and writes identical values to both triangles of g_fock.
             *
             * We can improve cache utilization by limiting or avoiding memory
             * access to one of the triangles.
             *
             * The following code separates the Coulomb and Exchange force update
             * so that we can use the symmetry of each to reduce memory operations
             * and limit access to the lower triangle. There are still some lower
             * triangle accesses, but they are significantly reduced.
             *
             * Once computed, the partial fock matrix will need some more processing
             * to make it symmetric again, but this can be done in an N^2 loop. To
             * get the final partial matrix, values from the upper and lower triangles
             * must be added together and written back to both triangles.
             *
             */

            UPDATE_COULOMB2(i,j,k,l);
            UPDATE_COULOMB2(k,l,i,j);

            UPDATE_EXCHANGE(i,j,k,l);
            UPDATE_EXCHANGE(i,j,l,k);
            UPDATE_EXCHANGE(j,i,k,l);
            UPDATE_EXCHANGE(j,i,l,k);
#endif
          } // l
        } // k
      } // j
    } // i
  }

#ifndef BAD_CACHE_UTILIZATION
  /*
   * Fix the partial fock matrix.
   * To improve cache utilization, the temp fock matricies had most, but not
   * all of their updates limited to the upper triangle. To get the correct
   * result, we need to add values from both the upper and lower triangles:
   *
   * The asymmetric partial fock matrix has the following form:
   *
   *  |   V(1,1)   V(1,2)   V(1,3)   V(1,4)  |
   *  |   s(2,1)   V(2,2)   V(2,3)   V(2,4)  |
   *  |   s(3,1)   s(3,2)   V(3,3)   V(3,4)  |
   *  |   s(4,1)   s(4,2)   s(4,3)   V(4,4)  |
   *
   *  Where V(i,j) is much larger than s(j,i)
   *
   *  To re-symmetrize:
   *
   * PARTIAL_FOCK(i,j) = ASYM_PARTIAL(i,j) + ASYM_PARTIAL(j,i)
   *
   * Which results in the correct partial fock matrix which has the form:
   *
   *  |     2 * V(1,1)      V(1,2) + s(2,1)   V(1,3) + s(3,1)   V(1,4) + s(4,1)  |
   *  |   s(2,1) + V(1,2)     2 * V(2,2)      V(2,3) + s(3,2)   V(2,4) + s(4,2)  |
   *  |   s(3,1) + V(1,3)   s(3,2) + V(2,3)     2 * V(3,3)      V(3,4) + s(4,3)  |
   *  |   s(4,1) + V(1,4)   s(4,2) + V(2,4)   s(4,3) + V(3,4)     2 * V(4,4)     |
   *
   */
  k_off = 0;
  for (k = 0; k < nbfn; k++) {
    l_off = k_off;
    for (l = k; l < nbfn; l++) {
      double value = fock[OFF(k,l)] + fock[OFF(l,k)];
      fock[OFF(k,l)] = value;
      fock[OFF(l,k)] = value;
      l_off += nbfn;
    }
    k_off += nbfn;
  }
#endif

  CUT_WRITEBACK;
}


void twoel_i_eq_j(double tol2e_over_schwmax, size_t thread) {
  CUT_DECLS;
  int i, k, l;
  int i_off, k_off, l_off;
  double* fock = twoel_context[thread].fock;

  // 4-way symmetry
  while ((i = get_work_unit_ij()) < nbfn) {
    int end = i + N3_CHUNK_SIZE;
    i_off = (i-1) * nbfn;

  for (; i < nbfn && i < end; i++) {
    i_off += nbfn;

    DENS_DECL(i,i);
    TOL_DECL(i,i);

    if (g_schwarz[OFF(i,i)] < tol2e_over_schwmax) {
      CUT1(4 * (1 + i - nbfn) * (i - nbfn) / 2);
      continue;
    }
    k_off = i_off - nbfn;

    for (k = i; k < nbfn; k++) {
      k_off += nbfn;
      DENS_DECL_SYMM(k,i);
      if (g_schwarz_max_j[k] < tol2e_over_g_schwarz_i_i) {
        CUT4(4 * (nbfn - k - 1));
        continue;
      }

      l_off = k_off;
      for (l = 1 + k; l < nbfn; l++) {
        l_off += nbfn;

        if (g_schwarz[OFF(k,l)] < tol2e_over_g_schwarz_i_i) {
          CUT2(4);
          continue;
        }

        DENS_DECL_SYMM(l,i);
        DENS_DECL_SYMM(l,k);

        CUT3(4);
        double gg = G(i, i, k, l);

#ifdef BAD_CACHE_UTILIZATION
        UPDATE(i,i,k,l);
        UPDATE(i,i,l,k);
        UPDATE(k,l,i,i);
        UPDATE(l,k,i,i);
#else
        UPDATE_COULOMB1(i,i,k,l);
        UPDATE_COULOMB1(k,l,i,i);

        UPDATE_EXCHANGE(i,i,k,l);
        UPDATE_EXCHANGE(i,i,l,k);
#endif
      } // l
    } // k
  } // i
  }

  CUT_WRITEBACK;
}

void twoel_k_eq_l(double tol2e_over_schwmax, size_t thread) {
  CUT_DECLS;
  int i, j, k;
  int i_off, j_off, k_off;
  double* fock = twoel_context[thread].fock;

  // 4-way symmetry
  while ((i = get_work_unit_kl()) < nbfn) {
    int end = i + N3_CHUNK_SIZE;
    i_off = (i-1) * nbfn;

  for (; i < nbfn && i < end; i++) {
    i_off += nbfn;
    j_off = i_off;

    for (j = i + 1; j < nbfn; j++) {
      j_off += nbfn;
      DENS_DECL_SYMM(j,i);
      TOL_DECL(i,j);

      if (g_schwarz[OFF(i,j)] < tol2e_over_schwmax) {
        CUT1(4 * (nbfn - i - 1));
        continue;
      }
      k_off = i_off;

      for (k = i + 1; k < nbfn; k++) {
        k_off += nbfn;

        DENS_DECL_SYMM(k,i);
        DENS_DECL_SYMM(k,j);
        DENS_DECL(k,k);

        if (g_schwarz[OFF(k,k)] < tol2e_over_g_schwarz_i_j) {
          CUT2(4);
          continue;
        }


        CUT3(4);
        double gg = G(i, j, k, k);

#ifdef BAD_CACHE_UTILIZATION
        UPDATE(i,j,k,k);
        UPDATE(j,i,k,k);
        UPDATE(k,k,i,j);
        UPDATE(k,k,j,i);
#else
        UPDATE_COULOMB1(i,j,k,k);
        UPDATE_COULOMB1(k,k,i,j);

        UPDATE_EXCHANGE(i,j,k,k);
        UPDATE_EXCHANGE(j,i,k,k);
#endif
      } // k
    } // j
  } // i
  }

  CUT_WRITEBACK;
}

void twoel_ij_eq_kl(double tol2e_over_schwmax, size_t thread) {
  CUT_DECLS;
  int i, j;
  int i_off, j_off;
  double* fock = twoel_context[thread].fock;

  // 4-way symmetry
  i_off = -nbfn;
  for (i = 0; i < nbfn; i++) {
    i_off += nbfn;
    j_off = i_off;

    DENS_DECL(i,i);

    for (j = i + 1; j < nbfn; j++) {
      j_off += nbfn;
      DENS_DECL_SYMM(j,i);
      DENS_DECL(j,j);
      TOL_DECL(i,j);

      if (g_schwarz[OFF(i,j)] < tol2e_over_g_schwarz_i_j) {
        CUT1(4);
        continue;
      }

      CUT3(4);
      double gg = G(i, j, i, j);

      UPDATE(i,j,i,j);
      UPDATE(i,j,j,i);
      UPDATE(j,i,i,j);
      UPDATE(j,i,j,i);
    } // j
  } // i

  CUT_WRITEBACK;
}

void twoel_i_eq_j_and_k_eq_l(double tol2e_over_schwmax, size_t thread) {
  CUT_DECLS;
  int i, k;
  int i_off, k_off;
  double* fock = twoel_context[thread].fock;

  // 2-way symmetry
  i_off = -nbfn;
  for (i = 0; i < nbfn; i++) {
    i_off += nbfn;

    DENS_DECL(i,i);
    TOL_DECL(i,i);

    if (g_schwarz[OFF(i,i)] < tol2e_over_schwmax) {
      CUT1(2 * (nbfn - i - 1));
      continue;
    }
    k_off = i_off;

    for (k = i + 1; k < nbfn; k++) {
      k_off += nbfn;
      DENS_DECL_SYMM(k,i);
      DENS_DECL(k,k);

      if (g_schwarz[OFF(k,k)] < tol2e_over_g_schwarz_i_i) {
        CUT2(2);
        continue;
      }

      CUT3(2);
      double gg = G(i, i, k, k);

      UPDATE(i,i,k,k);
      UPDATE(k,k,i,i);
    } // k
  } // i

  CUT_WRITEBACK;
}


void twoel_i_eq_j_eq_k_eq_l(double tol2e_over_schwmax, size_t thread) {
  CUT_DECLS;
  int i;
  int i_off;
  double* fock = twoel_context[thread].fock;

  // 1-way symmetry
  i_off = -nbfn;
  for (i = 0; i < nbfn; i++) {
    i_off += nbfn;

    DENS_DECL(i,i);
    TOL_DECL(i,i);

    if (g_schwarz[OFF(i,i)] < tol2e_over_g_schwarz_i_i) {
      CUT2(1);
      continue;
    }

    CUT3(1);
    double gg = G(i, i, i, i);

    UPDATE(i,i,i,i);
  } // i

  CUT_WRITEBACK;
}

CODELET_IMPL_BEGIN_NOCANCEL(twoel_codelet)
  double tol2e_over_schwmax = tol2e / schwmax;

  g_i = 0;
  g_ij = 0;
  g_kl = 0;
  g_codelet_num = 1;

  finalize_codelet = NEXT;
  finalize_context = NEXT_THIS;

  swarm_Dep_init(&dep, g_threads + 1, &CODELET(twoel_local_reduction), NULL, NULL);

  swarm_Locale_scheduleToLeaves(
              swarm_getRootLocale(0), ~(size_t)0,
              &CODELET(twoel_symm), NULL, NULL, NULL, NULL,
              swarm_Scheduler_ORDER_FIFO);

  // do the N^2 and smaller loops

  ENTER_LOG(twoel_ij_eq_kl);
  twoel_ij_eq_kl(tol2e_over_schwmax, 0);
  EXIT_LOG(twoel_ij_eq_kl);

  ENTER_LOG(twoel_i_eq_j_and_k_eq_l);
  twoel_i_eq_j_and_k_eq_l(tol2e_over_schwmax, 0);
  EXIT_LOG(twoel_i_eq_j_and_k_eq_l);

  ENTER_LOG(twoel_i_eq_j_eq_k_eq_l);
  twoel_i_eq_j_eq_k_eq_l(tol2e_over_schwmax, 0);
  EXIT_LOG(twoel_i_eq_j_eq_k_eq_l);

  swarm_Dep_satisfy(&dep, 1);

CODELET_IMPL_END;

CODELET_IMPL_BEGIN_NOCANCEL(twoel_symm)
  double tol2e_over_schwmax = tol2e / schwmax;
  size_t me = swarm_atomic_getAndInc(g_codelet_num);

  // Do the N^3 loops

  ENTER_LOG(twoel_i_eq_j);
  twoel_i_eq_j(tol2e_over_schwmax, me);
  EXIT_LOG(twoel_i_eq_j);

  ENTER_LOG(twoel_k_eq_l);
  twoel_k_eq_l(tol2e_over_schwmax, me);
  EXIT_LOG(twoel_k_eq_l);

  // Now, do the big loop

  ENTER_LOG(twoel_i_j_k_l_all_different);
  twoel_i_j_k_l_all_different(tol2e_over_schwmax, me);
  EXIT_LOG(twoel_i_j_k_l_all_different);

  swarm_Dep_satisfy(&dep, 1);
CODELET_IMPL_END;

CODELET_IMPL_BEGIN_NOCANCEL(twoel_local_reduction)
  size_t t, i, j;
  size_t i_off;
  size_t nbfn_squared = nbfn * nbfn;
  size_t t_off = 0;

  t_off = 0;
  for (t = 0; t < g_threads + 1; t++) {
    i_off=0;
    for (i = 0; i < nbfn; i++) {
      for (j = 0; j < nbfn; j++) {
        g_fock[i_off + j] += t_fock[t_off + i_off + j];
        t_fock[t_off + i_off + j] = 0.0;
      }
      i_off += nbfn;
    }
    t_off += nbfn_squared;
  }

  for (t = 0; t < g_threads + 1; t++) {
    icut1 += twoel_context[t].icut1;
    icut2 += twoel_context[t].icut2;
    icut3 += twoel_context[t].icut3;
    icut4 += twoel_context[t].icut4;

    twoel_context[t].icut1 = 0;
    twoel_context[t].icut2 = 0;
    twoel_context[t].icut3 = 0;
    twoel_context[t].icut4 = 0;
  }

  swarm_dispatch(finalize_codelet, finalize_context, NULL, NULL, NULL);
CODELET_IMPL_END;

double twoel_swarm() {
  swarm_callInto(runtime, &CODELET(twoel_codelet), NULL, NULL);

  return (0.50 * contract_matrices(g_fock, g_dens));
}

